
#include "Light.h"

Light::Light()
{
}

Light::~Light()
{
}

void Light::preprocess()
{
}
