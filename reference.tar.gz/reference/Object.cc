
#include "Object.h"

Object::Object()
{
}

Object::~Object()
{
}

void Object::preprocess()
{
}
