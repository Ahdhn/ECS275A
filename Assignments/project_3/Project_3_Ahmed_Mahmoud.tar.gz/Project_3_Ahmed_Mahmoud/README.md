Path tracer was implemented with global illumination, penumbra shadow and area light sources based on the code given in the reference.tar.gz., Assignment 1 and Assignment 2. A large part of the modified code specially the parser and the input files was inspired from Computer Graphics II (Spring 2009) given in Utah University
<http://www.cs.utah.edu/~acumming/cs6620/Computer_Graphics_II/Computer_Graphics_II_Spring_2009/Computer_Graphics_II_Spring_2009.html>


The code was developed under Windows environment (Visual Studio 2013). It was tested to run under Linux environment using Cygwin. Using Cygwin, I was able to cd to where the code is, then 'cmake CMakeLists.txt' followed by 'make' should produce the executable (specter.exe). 

The images in "output_images" are:
- "simple_cornell_box_progress" shows the progess of the path tracer and how the quality of the output improves from one iteration to another 
- The output from the above should be compared with the image in "simple_cornell_box_red" to show how the shading from the red wall affect the right and left walls 
- "simple_cornell_box_one_spheres" shows clearly the soft shadow as the sphere is close to the light source and shadow has large area to cover
- "simple_cornell_box_two_spheres" shows a shere with mirror refelction 

-ahmed
