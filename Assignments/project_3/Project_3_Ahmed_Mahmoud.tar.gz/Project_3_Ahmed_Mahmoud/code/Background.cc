
#include "Background.h"

Background::Background()
{
}

Background::~Background()
{
}

void Background::preprocess()
{
}
