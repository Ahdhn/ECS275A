
#include "Material.h"

Material::Material()
{
}

Material::~Material()
{
}

void Material::preprocess()
{
}

